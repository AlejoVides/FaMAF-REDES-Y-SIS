# Preguntas conceptuales
___
1. ¿Cómo sabe el cliente que terminó de recibir la respuesta?

La respuesta trabaja bajo el protocolo HTTP, dentro del formato del mensaje hay headers que indican el tamaño del cuerpo, cuando se recibe esa cantidad de bytes el cliente considera que el la respuesta HTTP terminó. En caso de que no se indique el tamaño exacto del cuerpo y se reciba en bloques, el recibir un bloque de tamaño 0 también indica que es el final del mensaje. 

2. ¿Qué parte del comportamiento depende de TCP y cuál de HTTP?

TCP es el medio de transporte te los datos, establece la conexión cliente-servidor y se encarga del manejo de errores de transporte o de perdidas hasta que detecta que la conexión terminó (sin la necesidad de interpretar los datos, TCP solo los transporta). HTTP se encarga de interpretar dichos datos, lee la estructura de los datos, headers y formatos de peticiones y respuestas.

3. ¿Qué pasaría si el servidor no cerrara la conexión después de enviar la respuesta?

En caso de que no se indique el tamaño del cuerpo y nunca se reciba un bloque de tamaño 0 el cliente no puede saber cuando ni dónde termina la respuesta, por lo que depende exclusivamente del servidor. 

4. ¿Por qué la IP obtenida para el mismo hostname podría ser distinta entre ejecuciones (o entre máquinas)?

Por el manejo de DNS's, puede devolver distintas direcciones para una misma dirección, un hostname puede asociarse a múltiples IP's en distintos servidores, puede variar por temas de velocidad o balanceo.

5. ¿Por qué DNS suele usar UDP y HTTP usa TCP? ¿Qué pasaría si usáramos TCP para las consultas DNS en este cliente? (opcional, profundización)

Las consultas de DNS's son muy pequeñas y UDP es más barato en ese caso, solo envía una consulta y una respuesta, no requiere que llegue en orden ni establecer una conexión antes de enviar datos. Pero no hay nada intrínsecamente con usar TCP, solo sería más costoso del lado del servidor y aumentaría la latencia.
Aún así tengo entendido que algunos casos particulares las consultas DNS pueden usar TCP si las respuestas son suficientemente grandes.
